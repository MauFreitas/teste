﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class segundo_dialogo : MonoBehaviour
{
    public GameObject Panel;
    public TextAsset arquivo;
    public string[] texto;
    public Text textoMensagem;
    public GameObject Continuar;
    public GameObject InfoTexto;

    private int fimDaLinha;
    private int linhaAtual;
    public bool iAtivo;
    // Start is called before the first frame update
    void Start()
    {

        if (arquivo != null)
        {
            texto = (arquivo.text.Split('\n'));

        }
        if (fimDaLinha == 0)
        {
            fimDaLinha = texto.Length;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (linhaAtual < fimDaLinha)
            {
                textoMensagem.text = texto[linhaAtual];
            }
            if (Panel.activeSelf)
            {
                linhaAtual += 1;
            }
        }
        if (linhaAtual > fimDaLinha)
        {
            linhaAtual = 0;
            //desabilitar();
            // Continuar.SetActive(true);
            InfoTexto.SetActive(false);
            SceneManager.LoadScene("level_2");
        }
    }
    void habilitar()
    {
        Panel.SetActive(true);
    }
    void desabilitar()
    {
        Panel.SetActive(false);

    }
}
